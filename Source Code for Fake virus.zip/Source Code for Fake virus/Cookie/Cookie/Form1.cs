﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cookie
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            button1.Enabled = true;
            
        }

        private void button1_Click(object sender, EventArgs e)

        {
            if (textBox3.Text == "19201987ender")
            {
                MessageBox.Show("Good job, Your system was recovered");
                MessageBox.Show("Bye have a nice day :)");
                Application.Exit();
            }else if (textBox3.Text == "I don't have a code.")
            {
                textBox3.Text = "your randomly generated code is 'id90781932'";
            }else if (textBox3.Text == "id90781932")
            {
                MessageBox.Show("Good job, Your system was recovered");
                MessageBox.Show("Bye have a nice day :)");
                Application.Exit();
            }
            
             
            
            else
            {
                textBox3.Text = "Not Correct";
                MessageBox.Show("You piece of loser enter again");
                MessageBox.Show("Hey i did not recognise your shitty click please try again :/");
                MessageBox.Show("I did not recognise it again bro, maybe your mouse is broken becasue my code is accurate as hell");
                MessageBox.Show("Goodbye You noob.");
                Application.Exit();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Hello Dear, Your Pc is now infected muahahaha");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("System32 is a critical System file in windows, all the important windowsfiles are located over here, once system32 is delete the os becomes inaccesible, Please Use the authentication code to get back your critical system files!");
            MessageBox.Show("There is still a chance! please enter the code, if you shutdown/reboot your system while this virus is running you can loose your data!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("if you don't have a code then don't get worried you can simply type the text i don't have a code in the box below, it will randomly generate a code, use that code to get the system back.!");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is a malware which is made for destroying the system files in C:, this virus was made for a sumbition on Endermanch, if ya ran this on your main pc i am sorry but your system is deleted please use the verification code!");
        }
    }
}
